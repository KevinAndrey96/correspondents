<a href="/administrator/create">Crear administrador</a>
<br>
<table style="border:1px solid" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Comisión</th>
            <th>Ciudad</th>
            <th>Acción</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>

<?php /**PATH C:\Users\User\Documents\Proyectos_laravel\correspondents\resources\views/administrators/index.blade.php ENDPATH**/ ?>