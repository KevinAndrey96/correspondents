<form method="POST" action="/user/update">
    <?php echo csrf_field(); ?>
    <label>Nombre:</label>
    <input type="text" name="name" value="<?php echo e($user->name); ?>">
    <br/>
    <br/>
    <label>Email:</label>
    <input type="email" name="email" value="<?php echo e($user->email); ?>">
    <br/>
    <br/>
    <label>Teléfono:</label>
    <input type="text" name="phone" value="<?php echo e($user->phone); ?>">
    <br/>
    <br/>
    <label>Tipo de documento:</label>
    <select name="document_type">
        <?php if($user->document_type == 'CC'): ?>
            <option value="CC" selected>CC</option>
            <option value="TI">TI</option>
            <option value="NIT">NIT</option>
        <?php endif; ?>
            <?php if($user->document_type == 'TI'): ?>
                <option value="TI" selected>TI</option>
                <option value="CI">CI</option>
                <option value="NIT">NIT</option>
            <?php endif; ?>
            <?php if($user->document_type == 'NIT'): ?>
                <option value="NIT" selected>NIT</option>
                <option value="CI">CI</option>
                <option value="TI">TI</option>
            <?php endif; ?>
    </select>
    <br/>
    <br/>
    <label>Número de documento:</label>
    <input type="text" name="document" value="<?php echo e($user->document); ?>">
    <br/>
    <br/>
    <label>Ciudad:</label>
    <input type="text" name="city" value="<?php echo e($user->city); ?>">
    <br/>
    <br/>
    <label>Dirección:</label>
    <input type="text" name="address" value="<?php echo e($user->address); ?>">
    <br/>
    <br/>
    <label>Comisión:</label>
    <input type="number" name="commission" min="1" value="<?php echo e($user->commission); ?>">
    <br/>
    <br/>
    <?php if(isset($user->transaction_limit)): ?>
        <label>Límite de transacciones:</label>
        <input type="number" name="transaction_limit" min="1" value="<?php echo e($user->transaction_limit); ?>">
        <br/>
        <br/>
    <?php endif; ?>
    <?php if(isset($user->priority)): ?>
        <label>Prioridad</label>
        <input type="number" name="priority" min="1" value="<?php echo e($user->priority); ?>">
        <br/>
        <br/>
    <?php endif; ?>
    <label>Contraseña:</label>
    <input type="password" name="password">
    <br/>
    <br/>
    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
    <input type="submit" value="Modificar">
</form>
<?php /**PATH C:\Users\User\Documents\Proyectos_laravel\correspondents\resources\views/users/edit.blade.php ENDPATH**/ ?>