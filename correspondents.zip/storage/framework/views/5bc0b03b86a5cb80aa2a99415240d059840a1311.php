<a href="/user/create?role=<?php echo e($role); ?>">
        <?php if($role == 'Administrator'): ?>
            Crear administrador
        <?php endif; ?>
        <?php if($role == 'Supplier'): ?>
            Crear proveedor
        <?php endif; ?>
        <?php if($role == 'Shopkeeper'): ?>
            Crear tendero
        <?php endif; ?>

</a>
    <table style="border:1px solid black;">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Tipo de documento</th>
                <th>Número de documento</th>
                <th>Ciudad</th>
                <th>Dirección</th>
                <th>Comisión</th>
                <?php if($role == 'Shopkeeper'): ?>
                    <th>Límite de transacciones</th>
                <?php endif; ?>
                <?php if($role == 'Supplier'): ?>
                    <th>Prioridad</th>
                <?php endif; ?>
                <th>Acción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->document_type); ?></td>
                    <td><?php echo e($user->document); ?></td>
                    <td><?php echo e($user->city); ?></td>
                    <td><?php echo e($user->address); ?></td>
                    <td><?php echo e($user->commission); ?></td>
                    <?php if($role == 'Shopkeeper'): ?>
                        <td><?php echo e($user->transaction_limit); ?></td>
                    <?php endif; ?>
                    <?php if($role == 'Supplier'): ?>
                        <td><?php echo e($user->priority); ?></td>
                    <?php endif; ?>
                    <td>
                        <a href="/user/edit/<?php echo e($user->id); ?>">Editar</a>
                        <br>
                        <a href="/user/delete/<?php echo e($user->id); ?>">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php /**PATH C:\Users\User\Documents\Proyectos_laravel\correspondents\resources\views/users/index.blade.php ENDPATH**/ ?>