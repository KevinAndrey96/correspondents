<form method="POST" action="/user/store">
    <?php echo csrf_field(); ?>
    <label>Nombre:</label>
    <input type="text" name="name">
    <br/>
    <br/>
    <label>Email:</label>
    <input type="email" name="email">
    <br/>
    <br/>
    <label>Teléfono:</label>
    <input type="text" name="phone">
    <br/>
    <br/>
    <label>Tipo de documento:</label>
    <select name="document_type">
        <option value="CC">CC</option>
        <option value="TI">TI</option>
        <option value="NIT">NIT</option>
    </select>
    <br/>
    <br/>
    <label>Número de documento:</label>
    <input type="text" name="document">
    <br/>
    <br/>
    <label>Ciudad:</label>
    <input type="text" name="city">
    <br/>
    <br/>
    <label>Dirección:</label>
    <input type="text" name="address">
    <br/>
    <br/>
    <label>Comisión:</label>
    <input type="number" name="commission" min="1">
    <br/>
    <br/>
    <?php if($role == 'Shopkeeper'): ?>
        <label>Límite de transacciones:</label>
        <input type="number" name="transaction_limit" min="1">
        <br/>
        <br/>
    <?php endif; ?>
    <?php if($role == 'Supplier'): ?>
        <label>Prioridad</label>
        <input type="number" name="priority" min="1">
        <br/>
        <br/>
    <?php endif; ?>
    <label>Contraseña:</label>
    <input type="password" name="password">
    <br/>
    <br/>
    <input type="hidden" value="<?php echo e($role); ?>" name="role">
    <input type="submit" value="Guardar">
</form>
<?php /**PATH C:\Users\User\Documents\Proyectos_laravel\correspondents\resources\views/users/create.blade.php ENDPATH**/ ?>