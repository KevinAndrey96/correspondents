<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class DeleteUsersController extends Controller
{
    public function delete($id)
    {
       User::destroy($id);

       return back();
    }
}
